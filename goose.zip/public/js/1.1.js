webpackJsonp([1],[
/* 0 */,
/* 1 */
/***/ (function(module, exports) {

	'use strict';

	$(".categories-trigger").dropdown();
	$(".lang-trigger").dropdown();

/***/ })
]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiMS4xLmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL2Zyb250ZW5kL2pzL2hlYWRlci9pbmRleC5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHN0cmljdCc7XHJcblxyXG4kKFwiLmNhdGVnb3JpZXMtdHJpZ2dlclwiKS5kcm9wZG93bigpO1xyXG4kKFwiLmxhbmctdHJpZ2dlclwiKS5kcm9wZG93bigpO1xyXG5cclxuXG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIGZyb250ZW5kL2pzL2hlYWRlci9pbmRleC5qcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7OyIsInNvdXJjZVJvb3QiOiIifQ==