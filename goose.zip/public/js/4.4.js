webpackJsonp([4,1],[
/* 0 */,
/* 1 */
/***/ (function(module, exports) {

	'use strict';

	$(".categories-trigger").dropdown();
	$(".lang-trigger").dropdown();

/***/ }),
/* 2 */
/***/ (function(module, exports) {

	'use strict';

	$(".main-owl-carousel").owlCarousel({
	    items: 1,
	    autoWidth: false,
	    dots: false,
	    nav: true
	});

	$('input.autocomplete').autocomplete({
	    data: {
	        "Apple": null,
	        "Microsoft": null,
	        "Google": 'https://placehold.it/250x250'
	    }
	});

	$('.datepicker').datepicker();

	$('select').formSelect();

	$(".slider").owlCarousel({
	    items: 1,
	    autoWidth: false,
	    dots: false,
	    nav: true
		});

/***/ })
]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiNC40LmpzIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vL2Zyb250ZW5kL2pzL2hlYWRlci9pbmRleC5qcyIsIndlYnBhY2s6Ly8vZnJvbnRlbmQvanMvbWFpbi1wYWdlL2luZGV4LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIid1c2Ugc3RyaWN0JztcclxuXHJcbiQoXCIuY2F0ZWdvcmllcy10cmlnZ2VyXCIpLmRyb3Bkb3duKCk7XHJcbiQoXCIubGFuZy10cmlnZ2VyXCIpLmRyb3Bkb3duKCk7XHJcblxyXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gZnJvbnRlbmQvanMvaGVhZGVyL2luZGV4LmpzIiwiJ3VzZSBzdHJpY3QnO1xyXG4kKFwiLm1haW4tb3dsLWNhcm91c2VsXCIpLm93bENhcm91c2VsKHtcclxuICAgIGl0ZW1zOiAxLFxyXG4gICAgYXV0b1dpZHRoOiBmYWxzZSxcclxuICAgIGRvdHM6IGZhbHNlLFxyXG4gICAgbmF2OiB0cnVlLFxyXG59KTtcclxuXHJcbiQoJ2lucHV0LmF1dG9jb21wbGV0ZScpLmF1dG9jb21wbGV0ZSh7XHJcbiAgICBkYXRhOiB7XHJcbiAgICAgICAgXCJBcHBsZVwiOiBudWxsLFxyXG4gICAgICAgIFwiTWljcm9zb2Z0XCI6IG51bGwsXHJcbiAgICAgICAgXCJHb29nbGVcIjogJ2h0dHBzOi8vcGxhY2Vob2xkLml0LzI1MHgyNTAnXHJcbiAgICB9LFxyXG59KTtcclxuXHJcbiQoJy5kYXRlcGlja2VyJykuZGF0ZXBpY2tlcigpO1xyXG5cclxuJCgnc2VsZWN0JykuZm9ybVNlbGVjdCgpO1xyXG5cclxuJChcIi5zbGlkZXJcIikub3dsQ2Fyb3VzZWwoe1xyXG4gICAgaXRlbXM6IDEsXHJcbiAgICBhdXRvV2lkdGg6IGZhbHNlLFxyXG4gICAgZG90czpmYWxzZSxcclxuICAgIG5hdjogdHJ1ZSxcclxufSk7XG5cblxuLy8gV0VCUEFDSyBGT09URVIgLy9cbi8vIGZyb250ZW5kL2pzL21haW4tcGFnZS9pbmRleC5qcyJdLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7O0FDSEE7QUFDQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFKQTtBQUNBO0FBTUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUhBO0FBREE7QUFDQTtBQU9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUpBOzs7Iiwic291cmNlUm9vdCI6IiJ9