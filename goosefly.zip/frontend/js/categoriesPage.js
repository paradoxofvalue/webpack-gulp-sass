$('.tabs').tabs();
