$('.modal').modal();
$('.modal.chat').modal();
$('.tabs').tabs();

$(".categories-trigger").dropdown();
$(".lang-trigger").dropdown();