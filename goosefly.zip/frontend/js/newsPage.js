$(".slider").owlCarousel({
    items: 1,
    autoWidth: false,
    dots: false,
    nav: true,
});